from src.game import RockPaperScissorsGame

def main():
    game = RockPaperScissorsGame()
    print("Welcome to Rock, Paper, Scissors AI!")

    while True:
        player_move = input("Enter move (rock/paper/scissors or 'quit'): ").lower()
        if player_move == 'quit':
            print("Thanks for playing!")
            print(game.get_scoreboard())
            break
        if player_move not in ['rock', 'paper', 'scissors']:
            print("Invalid move! Try again.")
            continue

        player, ai, result = game.play_round(player_move)
        print(f"AI chose: {ai}")
        print(result)
        print(game.get_scoreboard())
        print("-" * 30)

if __name__ == "__main__":
    main()
