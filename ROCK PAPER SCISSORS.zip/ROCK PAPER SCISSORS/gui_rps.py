import tkinter as tk
from tkinter import ttk
import random

MOVES = ["rock", "paper", "scissors"]

class AIPlayer:
    def __init__(self):
        self.player_history = []

    def predict_move(self):
        if not self.player_history:
            return random.choice(MOVES)
        most_common = max(set(self.player_history), key=self.player_history.count)
        if most_common == 'rock':
            return 'paper'
        elif most_common == 'paper':
            return 'scissors'
        else:
            return 'rock'

    def update_history(self, player_move):
        self.player_history.append(player_move)

class GameApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Rock, Paper, Scissors AI")
        self.root.geometry("400x400")
        self.root.config(bg="#f0f0f0")

        self.ai = AIPlayer()
        self.player_score = 0
        self.ai_score = 0
        self.draws = 0

        self.create_widgets()

    def create_widgets(self):
        self.title_label = tk.Label(self.root, text="Rock, Paper, Scissors AI", font=("Arial", 16, "bold"), bg="#f0f0f0")
        self.title_label.pack(pady=10)

        self.button_frame = tk.Frame(self.root, bg="#f0f0f0")
        self.button_frame.pack(pady=10)

        for move in MOVES:
            btn = ttk.Button(self.button_frame, text=move.capitalize(), command=lambda m=move: self.play_round(m))
            btn.pack(side="left", padx=10)

        self.result_label = tk.Label(self.root, text="", font=("Arial", 14), bg="#f0f0f0")
        self.result_label.pack(pady=10)

        self.score_label = tk.Label(self.root, text=self.get_score_text(), font=("Arial", 12), bg="#f0f0f0")
        self.score_label.pack(pady=10)

        self.move_label = tk.Label(self.root, text="", font=("Arial", 12), bg="#f0f0f0")
        self.move_label.pack(pady=10)

    def play_round(self, player_move):
        ai_move = self.ai.predict_move()
        self.ai.update_history(player_move)

        if player_move == ai_move:
            result = "Draw"
            self.draws += 1
        elif (player_move == "rock" and ai_move == "scissors") or \
             (player_move == "paper" and ai_move == "rock") or \
             (player_move == "scissors" and ai_move == "paper"):
            result = "Player wins!"
            self.player_score += 1
        else:
            result = "AI wins!"
            self.ai_score += 1

        self.result_label.config(text=result)
        self.move_label.config(text=f"You chose {player_move}, AI chose {ai_move}")
        self.score_label.config(text=self.get_score_text())

    def get_score_text(self):
        return f"Score - Player: {self.player_score}, AI: {self.ai_score}, Draws: {self.draws}"

if __name__ == "__main__":
    root = tk.Tk()
    app = GameApp(root)
    root.mainloop()
