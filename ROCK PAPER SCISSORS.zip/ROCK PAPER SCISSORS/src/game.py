from src.ai import AIPlayer

class RockPaperScissorsGame:
    def __init__(self):
        self.ai = AIPlayer()
        self.player_score = 0
        self.ai_score = 0
        self.draws = 0

    def get_winner(self, player, ai):
        if player == ai:
            self.draws += 1
            return "Draw"
        elif (player == "rock" and ai == "scissors") or \
             (player == "paper" and ai == "rock") or \
             (player == "scissors" and ai == "paper"):
            self.player_score += 1
            return "Player wins!"
        else:
            self.ai_score += 1
            return "AI wins!"

    def play_round(self, player_move):
        ai_move = self.ai.predict_move()
        self.ai.update_history(player_move)
        result = self.get_winner(player_move, ai_move)
        return player_move, ai_move, result

    def get_scoreboard(self):
        return f"Score -> Player: {self.player_score}, AI: {self.ai_score}, Draws: {self.draws}"
