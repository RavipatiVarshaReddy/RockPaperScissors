import random

class AIPlayer:
    def __init__(self):
        self.player_history = []

    def predict_move(self):
        if not self.player_history:
            return random.choice(['rock', 'paper', 'scissors'])
        
        most_common = max(set(self.player_history), key=self.player_history.count)
        # Counter strategy
        if most_common == 'rock':
            return 'paper'
        elif most_common == 'paper':
            return 'scissors'
        else:
            return 'rock'

    def update_history(self, player_move):
        self.player_history.append(player_move)
