# Rock, Paper, Scissors AI

A Python game where you play against an AI that learns your moves using pattern recognition. The AI tries to predict your next move based on history.

## Features
- Basic rule-based AI
- Player move history tracking
- Beginner-friendly logic

## How to Run
```bash
python main.py
